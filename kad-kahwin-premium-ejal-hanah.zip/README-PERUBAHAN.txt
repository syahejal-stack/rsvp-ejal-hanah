Premium polish:
- Butang pembukaan lebih kecil, elegan dan tanpa emoji
- Transisi fade apabila jemputan dibuka
- Kelopak dikurangkan kepada 7
- Video tidak dizoom; latar video kabur memenuhi skrin
- Video dimainkan sekali dan turun ke butiran majlis selepas tamat
- Nama ibu bapa kedua-dua pihak
- Countdown ke 10 Januari 2027
- Butang Maps, RSVP, Simpan Tarikh dan Kongsi
- Kawalan lagu kekal sebagai satu butang kecil terapung
