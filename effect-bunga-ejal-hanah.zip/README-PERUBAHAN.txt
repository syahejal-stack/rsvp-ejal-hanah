Effect sahaja:
- Kelopak bunga bergerak jatuh perlahan
- Bunga sudut bergerak lembut
- Cahaya romantik bergerak
- Video zoom/pan perlahan
- Lagu tidak diubah
