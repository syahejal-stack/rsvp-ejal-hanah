Perubahan:
- Butang Maps berulang dibuang
- Butang RSVP berulang dibuang
- Google Maps kekal pada bahagian lokasi
- Borang RSVP kekal di bahagian RSVP
- Satu butang kecil Simpan Tarikh kekal bawah countdown
