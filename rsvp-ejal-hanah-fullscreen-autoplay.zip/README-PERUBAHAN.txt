Versi baharu:
- Video memenuhi satu skrin penuh
- Autoplay tanpa suara (syarat browser)
- Butang Buka suara/Tutup suara
- Tiada teks VIDEO JEMPUTAN
- Google Maps dan RSVP kekal pada halaman sama
