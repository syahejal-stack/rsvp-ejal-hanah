Perubahan:
- Tekan Buka Jemputan untuk cuba masuk full screen
- Bar pelayar disorok jika browser membenarkan
- Video tidak dizoom lagi
- object-fit contain digunakan supaya imej tidak dipaksa regang atau pecah
- Lagu dan video masih mula serentak
