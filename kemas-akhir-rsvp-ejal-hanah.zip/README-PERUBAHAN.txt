Semakan akhir:
- Buang ayat Jawapan disimpan secara terus / WhatsApp tidak akan dibuka
- Tetamu Tidak hadir atau Belum pasti disimpan sebagai 0 orang
- Nama dan catatan dibersihkan daripada ruang kosong berlebihan
- Bahagian video, countdown, kalendar, Maps, RSVP dan ucapan dikekalkan
