const ADMIN_PIN = "12486";
const VALID_STATUSES = new Set(["Hadir", "Tidak hadir", "Belum pasti"]);

function getDatabase(env) {
  return env.DB || env.MY_BINDING || null;
}

async function readyDatabase(env) {
  const db = getDatabase(env);
  if (!db) throw new Error("D1 binding DB belum disambungkan.");

  await db.prepare(`CREATE TABLE IF NOT EXISTS rsvps (
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL,
    pax INTEGER NOT NULL DEFAULT 0,
    note TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`).run();

  return db;
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff"
    }
  });
}

function cleanText(value, maxLength) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function isAdmin(request) {
  return request.headers.get("x-admin-pin") === ADMIN_PIN;
}

async function handleApi(request, env, url) {
  if (url.pathname === "/api/health") {
    if (!getDatabase(env)) {
      return json({ ok: false, database: false, error: "D1 binding DB belum disambungkan." }, 503);
    }

    try {
      await readyDatabase(env);
      return json({ ok: true, database: true });
    } catch (error) {
      console.error("RSVP health error", error);
      return json({ ok: false, database: true, error: "Database belum bersedia." }, 500);
    }
  }

  if (url.pathname !== "/api/rsvp") {
    return json({ error: "Tidak dijumpai." }, 404);
  }

  if (request.method === "POST") {
    try {
      const body = await request.json();
      const name = cleanText(body?.name, 100);
      const status = cleanText(body?.status, 30);
      const note = cleanText(body?.note, 300);
      const pax = status === "Hadir"
        ? Math.max(1, Math.min(6, Number(body?.pax) || 1))
        : 0;

      if (!name || !VALID_STATUSES.has(status)) {
        return json({ error: "Maklumat RSVP tidak lengkap." }, 400);
      }

      const db = await readyDatabase(env);
      await db.prepare(
        "INSERT INTO rsvps (name, status, pax, note) VALUES (?, ?, ?, ?)"
      ).bind(name, status, pax, note).run();

      return json({ saved: true }, 201);
    } catch (error) {
      console.error("RSVP POST error", error);
      return json({ error: "Jawapan belum dapat disimpan. Sila cuba lagi." }, 500);
    }
  }

  if (request.method === "GET") {
    try {
      const db = await readyDatabase(env);

      if (url.searchParams.get("public") === "1") {
        const result = await db.prepare(`SELECT id, name, note,
          created_at AS createdAt
          FROM rsvps
          WHERE note <> ''
          ORDER BY id DESC
          LIMIT 50`).all();

        return json({ entries: result.results || [] });
      }

      if (!isAdmin(request)) {
        return json({ error: "PIN tidak sah." }, 401);
      }

      const result = await db.prepare(`SELECT id, name, status, pax, note,
        created_at AS createdAt
        FROM rsvps
        ORDER BY id DESC
        LIMIT 1000`).all();

      return json({ entries: result.results || [] });
    } catch (error) {
      console.error("RSVP GET error", error);
      return json({ error: "Senarai RSVP belum dapat dibuka." }, 500);
    }
  }

  if (request.method === "DELETE") {
    if (!isAdmin(request)) {
      return json({ error: "PIN tidak sah." }, 401);
    }

    try {
      const body = await request.json();
      const id = Number(body?.id);
      if (!Number.isInteger(id) || id < 1) {
        return json({ error: "ID tidak sah." }, 400);
      }

      const db = await readyDatabase(env);
      await db.prepare("DELETE FROM rsvps WHERE id = ?").bind(id).run();
      return json({ deleted: true });
    } catch (error) {
      console.error("RSVP DELETE error", error);
      return json({ error: "Catatan belum dapat dipadam." }, 500);
    }
  }

  return json({ error: "Kaedah tidak disokong." }, 405);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    try {
      if (url.pathname.startsWith("/api/")) {
        return await handleApi(request, env, url);
      }

      if (url.pathname === "/semakan" || url.pathname === "/semakan/") {
        return Response.redirect(new URL("/?semakan=1", url), 302);
      }

      if (!env.ASSETS) {
        return json({ error: "Static assets belum tersedia." }, 503);
      }

      return env.ASSETS.fetch(request);
    } catch (error) {
      console.error("Worker error", error);
      return json({ error: "Ralat pelayan." }, 500);
    }
  }
};
