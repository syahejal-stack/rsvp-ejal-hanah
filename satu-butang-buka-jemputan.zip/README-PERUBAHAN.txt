Satu butang sahaja:
- Butang Buka Jemputan berada di tengah video
- Sekali tekan: video dan lagu baharu mula serentak
- Audio lama dalam video sentiasa senyap
- Butang lagu di bawah dibuang
- Selepas dibuka, satu butang Jeda/Sambung kekal
