Perubahan:
- Buang logik tetamu lama/baru
- Buang teks Tonton Semula Video
- Buang semua perkataan video pada butang
- Kekalkan dua pilihan tetap: Terus ke maklumat majlis dan Play
