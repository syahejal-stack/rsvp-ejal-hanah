Perubahan:
- Tambah butang Langkau video
- Langkau terus ke alamat, Maps dan RSVP
- Tetamu yang pernah membuka kad akan nampak Terus ke maklumat majlis sebagai pilihan utama
- Video masih boleh ditonton semula
- Arrow bawah menjadi hiasan sahaja dan tidak lagi boleh ditekan
