Perubahan:
- Butang Play dipindahkan ke atas sebagai pilihan utama
- Terus ke maklumat majlis dipindahkan ke bawah
- Simpan Tarikh ditukar kepada Tambah ke Kalendar
- Butang kalendar dikecilkan dan diberi ikon kalendar minimal
